#!/bin/sh

mkdir -p /succ/new
podman build -t the-image . -o type=local,dest=/succ/new && touch /succ/migration-flag
