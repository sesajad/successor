mkdir -p /succ/old
mount $(findmnt / -no source) /succ/old